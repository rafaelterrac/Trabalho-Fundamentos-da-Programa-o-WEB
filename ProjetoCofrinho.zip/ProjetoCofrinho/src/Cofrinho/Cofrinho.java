package Cofrinho;

import java.util.ArrayList;



class Cofrinho {
    private ArrayList<Moeda> moedas;

    public Cofrinho() {
        moedas = new ArrayList<>();                // Começo do ArrayList das moedas
    }

    public void adicionarMoeda(Moeda moeda) {
        moedas.add(moeda);                                 // Adiciona a moeda a lista de moedas
        System.out.println(moeda.getNome() + " adicionado.");         // Mostra que a moeda foi adicionada
    }

    public void removerMoeda(int indice) {
        if (indice >= 0 && indice < moedas.size()) {
            Moeda moedaRemovida = moedas.remove(indice);          // Remove a moeda do indíce indicado
            System.out.println(moedaRemovida.getNome() + " removido.");      // Exibe mensagem falando que removeu
        } else {
            System.out.println("Nenhuma moeda encontrada para remover.");        // Imprime a mensagem que não achou moeda para remover
        }
    }

    public void listarMoedas() {
        if (moedas.isEmpty()) {
            System.out.println("O cofrinho está vazio.");       //Imprime a mensagem de estiver vazio
        } else {
            System.out.println("Moedas no cofrinho:");           // Mostra as moedas que estão no cofrinho
            for (int i = 0; i < moedas.size(); i++) {
                Moeda moeda = moedas.get(i);
                System.out.println(i + ": " + moeda.getNome() + " (" + moeda.getPais() + ") - Valor: " + moeda.getValor());
            }
        }
    }

    public double calcularTotalEmReais() {
        double total = 0;
        for (Moeda moeda : moedas) {
            if (moeda instanceof Real) {
                total += moeda.getValor();
            } else if (moeda instanceof Dolar) {
                total += moeda.getValor() * 5.17;   // Conversão para Real
            } else if (moeda instanceof Euro) {
                total += moeda.getValor() * 5.75;   // Conversão para Real
            }
        }
        return total;                    // retorna o valor total em reais
    }
}

