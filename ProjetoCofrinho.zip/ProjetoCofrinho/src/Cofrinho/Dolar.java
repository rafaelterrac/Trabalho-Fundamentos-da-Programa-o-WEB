package Cofrinho;

class Dolar extends Moeda {                       // Classe filha ligada a Classe Mãe Moeda
    public Dolar(double valor) {
        super("Estados Unidos", valor);           // Chama o construtor da classe mãe (Moeda) com o país e valor da moeda
    }

    public String getNome() {
        return "Dólar";                      // retorna o nome da moeda
    }
}


