package Cofrinho;

class Euro extends Moeda {                          // Classe filha ligada a Classe Mãe Moeda
    public Euro(double valor) {
        super("Europa", valor);                  // Chama o construtor da classe mãe (Moeda) com o país e valor da moeda
    }

    public String getNome() {
        return "Euro";                           // retorna o nome da moeda
    }
}
