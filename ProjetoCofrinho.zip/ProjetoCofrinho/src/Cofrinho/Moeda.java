package Cofrinho;

abstract class Moeda {
    protected String pais;
    protected double valor;

    public Moeda(String pais, double valor) {
        this.pais = pais;
        this.valor = valor;
    }

    public abstract String getNome();             // para obter o nome da moeda

    public String getPais() {
        return pais;                   // retorna o país da moeda
    }

    public double getValor() {
        return valor;                    // retorna o valor da moeda
    }
}
