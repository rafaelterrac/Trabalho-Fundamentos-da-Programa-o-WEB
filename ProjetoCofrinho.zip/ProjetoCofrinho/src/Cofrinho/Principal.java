package Cofrinho;

import java.util.Scanner;


public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();

        int opcao = 0;
        while (opcao != 5) {
            System.out.println("*----- Menu -----*");                   // Menu de seleção de opções
            System.out.println("1- Adicionar moeda"); 
            System.out.println("2- Remover moeda");
            System.out.println("3- Listar moedas");
            System.out.println("4- Calcular total em REAIS");
            System.out.println("5- Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();                       // Lê a op~çao escolhida

            switch (opcao) {
                case 1:
                    System.out.println("Selecione o tipo de moeda:");          // Opção de adicionar Moeda
                    System.out.println("1- Real");
                    System.out.println("2- Dólar");
                    System.out.println("3- Euro");
                    System.out.print("Opção: ");
                    int tipoMoeda = scanner.nextInt();                  // Lê o tipo de moeda
                    System.out.print("Informe o valor da moeda: "); 
                    double valor = scanner.nextDouble();                   // Lê o valor da moeda
                    Moeda moeda;

                    switch (tipoMoeda) {
                        case 1:
                            moeda = new Real(valor);
                            break;
                        case 2:
                            moeda = new Dolar(valor);
                            break;
                        case 3:
                            moeda = new Euro(valor);
                            break;
                        default:
                            System.out.println("Opção inválida. Moeda não adicionada.");
                            continue;                                  // Se a opção for inválida continua pro proximo loop
                    }

                    cofrinho.adicionarMoeda(moeda);                    // Adiciona a moeda ao cofrinho
                    break;
                case 2:
                    System.out.print("Informe o número na listagem da moeda a ser removida: ");         
                    int indice = scanner.nextInt();                  // Lê o indicie da moeda a ser removica
                    cofrinho.removerMoeda(indice);                      // Remove as moedas
                    break;
                case 3:
                    cofrinho.listarMoedas();                                    // Lista as moedas que estão no cofrinho
                    break;
                case 4:
                    double total = cofrinho.calcularTotalEmReais();                 // Calcula o valor total das moedas em REAIS
                    System.out.println("Total em reais: R$" + total);
                    break;
                case 5:
                    System.out.println("Fechando o Programa.");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }

            System.out.println();
        }

        scanner.close();                     // Fecha scanner
    }
}
