package Cofrinho;

class Real extends Moeda {                           // Classe filha ligada a Classe Mãe Moeda
    public Real(double valor) {
        super("Brasil", valor);           // Chama o construtor da classe mãe (Moeda) com o país e valor da moeda
    }

    public String getNome() {
        return "Real";                     // Retorna o nome da moeda
    }
    
}